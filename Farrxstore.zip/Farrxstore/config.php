<?php

$conn = mysqli_connect('localhost','root','','farrxstore_db');

?>